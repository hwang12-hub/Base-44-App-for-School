import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { GraduationCap } from "lucide-react";
import { Link } from "react-router-dom";
import { CalendarDays } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import StatsOverview from "../components/dashboard/StatsOverview";
import AISummary from "../components/dashboard/AISummary";
import FeedbackCard from "../components/feedback/FeedbackCard";
import RatingsOverTimeChart from "../components/dashboard/RatingsOverTimeChart";
import TeacherRatingsChart from "../components/dashboard/TeacherRatingsChart";

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [checkingAuth, setCheckingAuth] = useState(true);

  useEffect(() => {
    base44.auth.me().then((u) => { setUser(u); setCheckingAuth(false); }).catch(() => setCheckingAuth(false));
  }, []);

  const { data: feedbacks = [], isLoading } = useQuery({
    queryKey: ["feedbacks"],
    queryFn: () => base44.entities.Feedback.list("-created_date"),
  });

  if (checkingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!user || user.role !== "admin") {
    return (
      <div className="fixed inset-0 flex flex-col items-center justify-center gap-4 text-center px-4">
        <GraduationCap className="w-12 h-12 text-muted-foreground" />
        <h2 className="text-xl font-semibold">Access Restricted</h2>
        <p className="text-muted-foreground text-sm max-w-xs">This page is only available to administrators.</p>
        <Link to="/"><Button variant="outline">Go to Home</Button></Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="p-2 rounded-xl bg-primary/10 group-hover:bg-primary/20 transition-colors">
              <span className="font-black text-primary text-base leading-none">H</span>
            </div>
            <span className="font-bold text-lg tracking-tight">H Academy</span>
          </Link>
          <div className="flex items-center gap-1">
            <Link to="/events">
              <Button variant="ghost" size="sm" className="gap-1.5"><CalendarDays className="w-4 h-4" />Events</Button>
            </Link>
            <Link to="/feedback">
              <Button variant="ghost" size="sm">Feedback</Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-10">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="mb-8">
            <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground mt-2">
              Overview of parent feedback and AI-powered insights.
            </p>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-20">
              <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
            </div>
          ) : (
            <div className="space-y-8">
              <StatsOverview feedbacks={feedbacks} />

              <div className="grid md:grid-cols-2 gap-6">
                <RatingsOverTimeChart feedbacks={feedbacks} />
                <TeacherRatingsChart feedbacks={feedbacks} />
              </div>

              <AISummary feedbacks={feedbacks} />

              <div>
                <h2 className="text-xl font-semibold mb-4">All Feedback ({feedbacks.length})</h2>
                {feedbacks.length === 0 ? (
                  <div className="text-center py-16 text-muted-foreground">
                    <p className="text-lg font-medium mb-1">No feedback yet</p>
                    <p className="text-sm">Share the feedback form with parents to start collecting responses.</p>
                  </div>
                ) : (
                  <div className="grid md:grid-cols-2 gap-4">
                    {feedbacks.map((fb) => (
                      <FeedbackCard key={fb.id} feedback={fb} />
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}