import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Send, CheckCircle2, GraduationCap, Images, CalendarDays, Settings } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import StarRating from "../components/feedback/StarRating";
import { Link } from "react-router-dom";
import ChatWidget from "../components/chatbot/ChatWidget";
import NotificationBell from "../components/notifications/NotificationBell";

export default function FeedbackForm() {
  const [userEmail, setUserEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    base44.auth.me().then((u) => { if (u?.email) setUserEmail(u.email); }).catch(() => {});
  }, []);
  const [form, setForm] = useState({
    parent_name: "",
    class_name: "",
    teacher_name: "",
    class_rating: 0,
    teacher_rating: 0,
    comments: "",
  });

  const mutation = useMutation({
    mutationFn: (data) => base44.entities.Feedback.create(data),
    onSuccess: () => setSubmitted(true),
    onError: () => toast.error("Failed to submit feedback."),
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.class_name || !form.teacher_name || !form.class_rating || !form.teacher_rating) {
      toast.error("Please fill in all required fields and ratings.");
      return;
    }
    mutation.mutate(form);
  };

  const update = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="p-2 rounded-xl bg-primary/10 group-hover:bg-primary/20 transition-colors">
              <span className="font-black text-primary text-base leading-none">H</span>
            </div>
            <span className="font-bold text-lg tracking-tight">H Academy</span>
          </Link>
          <div className="flex items-center gap-1">
            <NotificationBell parentEmail={userEmail} />
            <Link to="/events">
              <Button variant="ghost" size="sm" className="gap-1.5"><CalendarDays className="w-4 h-4" />Events</Button>
            </Link>
            <Link to="/gallery">
              <Button variant="ghost" size="sm" className="gap-1.5"><Images className="w-4 h-4" />Gallery</Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-4 py-10">
        <AnimatePresence mode="wait">
          {submitted ? (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center justify-center py-20 text-center"
            >
              <div className="p-4 rounded-full bg-chart-3/10 mb-6">
                <CheckCircle2 className="w-12 h-12 text-chart-3" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Thank you!</h2>
              <p className="text-muted-foreground mb-6">Your feedback has been submitted successfully.</p>
              <Button onClick={() => { setSubmitted(false); setForm({ parent_name: "", class_name: "", teacher_name: "", class_rating: 0, teacher_rating: 0, comments: "" }); }}>
                Submit Another
              </Button>
            </motion.div>
          ) : (
            <motion.div
              key="form"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="mb-8">
                <h1 className="text-3xl font-bold tracking-tight">Share Your Feedback</h1>
                <p className="text-muted-foreground mt-2">
                  Help us improve by rating your child's class and teacher experience.
                </p>
              </div>

              <Card className="border-border/50 shadow-sm">
                <CardContent className="p-6 md:p-8">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <Label htmlFor="parent_name">Your Name (optional)</Label>
                      <Input
                        id="parent_name"
                        placeholder="e.g. Jane Smith"
                        value={form.parent_name}
                        onChange={(e) => update("parent_name", e.target.value)}
                        className="mt-1.5"
                      />
                    </div>

                    <div className="grid sm:grid-cols-2 gap-5">
                      <div>
                        <Label htmlFor="class_name">Class Name *</Label>
                        <Input
                          id="class_name"
                          placeholder="e.g. Math 101"
                          value={form.class_name}
                          onChange={(e) => update("class_name", e.target.value)}
                          className="mt-1.5"
                        />
                      </div>
                      <div>
                        <Label htmlFor="teacher_name">Teacher Name *</Label>
                        <Input
                          id="teacher_name"
                          placeholder="e.g. Mr. Johnson"
                          value={form.teacher_name}
                          onChange={(e) => update("teacher_name", e.target.value)}
                          className="mt-1.5"
                        />
                      </div>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-5">
                      <div>
                        <Label className="mb-2 block">Class Satisfaction *</Label>
                        <StarRating value={form.class_rating} onChange={(v) => update("class_rating", v)} />
                      </div>
                      <div>
                        <Label className="mb-2 block">Teacher Satisfaction *</Label>
                        <StarRating value={form.teacher_rating} onChange={(v) => update("teacher_rating", v)} />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="comments">Additional Comments</Label>
                      <Textarea
                        id="comments"
                        placeholder="Tell us more about your experience..."
                        value={form.comments}
                        onChange={(e) => update("comments", e.target.value)}
                        className="mt-1.5 min-h-[120px]"
                      />
                    </div>

                    <Button
                      type="submit"
                      className="w-full gap-2"
                      size="lg"
                      disabled={mutation.isPending}
                    >
                      {mutation.isPending ? (
                        <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                      ) : (
                        <Send className="w-4 h-4" />
                      )}
                      Submit Feedback
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      <ChatWidget />
    </div>
  );
}