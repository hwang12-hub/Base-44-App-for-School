import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { GraduationCap, Upload, ImageIcon, Video, X, Loader2, ShieldCheck } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import ChatWidget from "../components/chatbot/ChatWidget";
import ModerationQueue from "../components/gallery/ModerationQueue";

export default function Gallery() {
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState(null);
  const [fileType, setFileType] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [form, setForm] = useState({ parent_name: "", caption: "" });
  const [isAdmin, setIsAdmin] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then((u) => { if (u?.role === "admin") setIsAdmin(true); }).catch(() => {});
  }, []);

  const { data: posts = [], isLoading } = useQuery({
    queryKey: ["posts"],
    queryFn: () => base44.entities.Post.filter({ status: "approved" }, "-created_date"),
  });

  const mutation = useMutation({
    mutationFn: async (data) => base44.entities.Post.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["posts"] });
      queryClient.invalidateQueries({ queryKey: ["posts-pending"] });
      setPreview(null);
      setSelectedFile(null);
      setFileType(null);
      setForm({ parent_name: "", caption: "" });
      toast.success("Post submitted! It will appear after admin review.");
    },
    onError: () => toast.error("Failed to share post."),
  });

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const type = file.type.startsWith("video") ? "video" : "image";
    setFileType(type);
    setSelectedFile(file);
    setPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!selectedFile) { toast.error("Please select an image or video."); return; }
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file: selectedFile });
    setUploading(false);
    mutation.mutate({ ...form, file_url, file_type: fileType, status: "pending" });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-primary/10">
              <GraduationCap className="w-5 h-5 text-primary" />
            </div>
            <span className="font-bold text-lg">EduFeedback</span>
          </div>
          <div className="flex items-center gap-2">
            {isAdmin && (
              <span className="flex items-center gap-1 text-xs font-medium text-primary bg-primary/10 px-2.5 py-1 rounded-full">
                <ShieldCheck className="w-3.5 h-3.5" /> Admin
              </span>
            )}
            <Link to="/"><Button variant="ghost" size="sm">Feedback Form</Button></Link>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-10">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Kids Gallery</h1>
          <p className="text-muted-foreground mt-2">Share photos and videos of your child's school moments.</p>
        </div>

        {/* Admin Moderation Queue */}
        {isAdmin && (
          <div className="mb-2">
            <div className="flex items-center gap-2 mb-4 p-3 bg-primary/5 border border-primary/20 rounded-xl">
              <ShieldCheck className="w-4 h-4 text-primary" />
              <p className="text-sm font-medium text-primary">Admin View — Moderation queue is visible only to you.</p>
            </div>
            <ModerationQueue />
          </div>
        )}

        {/* Upload Form */}
        <Card className="border-border/50 shadow-sm mb-10">
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <Label htmlFor="parent_name">Your Name (optional)</Label>
                <Input
                  id="parent_name"
                  placeholder="e.g. Jane Smith"
                  value={form.parent_name}
                  onChange={(e) => setForm((p) => ({ ...p, parent_name: e.target.value }))}
                  className="mt-1.5"
                />
              </div>

              <div>
                <Label htmlFor="caption">Caption (optional)</Label>
                <Textarea
                  id="caption"
                  placeholder="Say something about this moment..."
                  value={form.caption}
                  onChange={(e) => setForm((p) => ({ ...p, caption: e.target.value }))}
                  className="mt-1.5 min-h-[80px]"
                />
              </div>

              <div>
                <Label>Photo or Video *</Label>
                <label
                  htmlFor="file-upload"
                  className="mt-1.5 flex flex-col items-center justify-center border-2 border-dashed border-border rounded-xl p-6 cursor-pointer hover:border-primary/50 hover:bg-primary/5 transition-colors"
                >
                  {preview ? (
                    <div className="relative w-full">
                      {fileType === "video" ? (
                        <video src={preview} controls className="rounded-lg max-h-64 mx-auto" />
                      ) : (
                        <img src={preview} alt="preview" className="rounded-lg max-h-64 mx-auto object-cover" />
                      )}
                      <button
                        type="button"
                        onClick={(e) => { e.preventDefault(); setPreview(null); setSelectedFile(null); setFileType(null); }}
                        className="absolute top-2 right-2 bg-background/80 rounded-full p-1 hover:bg-background"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <div className="flex gap-3 mb-2">
                        <ImageIcon className="w-6 h-6 text-muted-foreground" />
                        <Video className="w-6 h-6 text-muted-foreground" />
                      </div>
                      <p className="text-sm text-muted-foreground">Click to upload a photo or video</p>
                      <p className="text-xs text-muted-foreground mt-1">JPG, PNG, MP4, MOV supported</p>
                    </>
                  )}
                </label>
                <input
                  id="file-upload"
                  type="file"
                  accept="image/*,video/*"
                  className="hidden"
                  onChange={handleFileChange}
                />
              </div>

              <Button type="submit" className="w-full gap-2" size="lg" disabled={uploading || mutation.isPending}>
                {(uploading || mutation.isPending) ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Upload className="w-4 h-4" />
                )}
                {uploading ? "Uploading..." : "Share Post"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Approved Posts Grid */}
        <h2 className="text-xl font-semibold mb-4">Public Feed</h2>
        {isLoading ? (
          <div className="flex justify-center py-16">
            <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
          </div>
        ) : posts.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <ImageIcon className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="font-medium">No posts yet</p>
            <p className="text-sm mt-1">Be the first to share a moment!</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-5">
            <AnimatePresence>
              {posts.map((post) => (
                <motion.div key={post.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
                  <Card className="overflow-hidden border-border/50 hover:shadow-lg transition-shadow">
                    {post.file_type === "video" ? (
                      <video src={post.file_url} controls className="w-full max-h-72 object-cover bg-black" />
                    ) : (
                      <img src={post.file_url} alt="post" className="w-full max-h-72 object-cover" />
                    )}
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">{post.parent_name || "Anonymous"}</span>
                        <span className="text-xs text-muted-foreground">{format(new Date(post.created_date), "MMM d, yyyy")}</span>
                      </div>
                      {post.caption && <p className="text-sm text-muted-foreground">{post.caption}</p>}
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
      <ChatWidget />
    </div>
  );
}