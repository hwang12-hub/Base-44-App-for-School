import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { GraduationCap, Bell, BookOpen, Dumbbell, Palette, Users, PartyPopper, MoreHorizontal, Star, Loader2, CheckCircle2 } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { motion } from "framer-motion";
import NotificationBell from "../components/notifications/NotificationBell";

const CATEGORIES = [
  { value: "academic", label: "Academic", icon: BookOpen, color: "text-primary" },
  { value: "sports",   label: "Sports",   icon: Dumbbell, color: "text-chart-3" },
  { value: "arts",     label: "Arts",     icon: Palette,  color: "text-chart-4" },
  { value: "social",   label: "Social",   icon: Users,    color: "text-accent-foreground" },
  { value: "holiday",  label: "Holiday",  icon: PartyPopper, color: "text-destructive" },
  { value: "other",    label: "Other",    icon: MoreHorizontal, color: "text-muted-foreground" },
];

export default function Settings() {
  const [user, setUser] = useState(null);
  const [parentName, setParentName] = useState("");
  const [parentEmail, setParentEmail] = useState("");
  const [emailLocked, setEmailLocked] = useState(false);
  const [savedSub, setSavedSub] = useState(null);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [selectedEventIds, setSelectedEventIds] = useState([]);
  const [saving, setSaving] = useState(false);
  const queryClient = useQueryClient();

  // Load logged-in user
  useEffect(() => {
    base44.auth.me().then((u) => {
      if (u) {
        setUser(u);
        setParentEmail(u.email);
        setParentName(u.full_name || "");
        setEmailLocked(true);
      }
    }).catch(() => {});
  }, []);

  const { data: events = [] } = useQuery({
    queryKey: ["events"],
    queryFn: () => base44.entities.Event.list("date"),
  });

  // Load existing subscription for this email
  const loadSubscription = async (email) => {
    if (!email) return;
    const subs = await base44.entities.EventSubscription.filter({ parent_email: email });
    if (subs.length > 0) {
      setSavedSub(subs[0]);
      setSelectedCategories(subs[0].subscribed_categories || []);
      setSelectedEventIds(subs[0].subscribed_event_ids || []);
      setParentName(subs[0].parent_name || parentName);
    }
  };

  useEffect(() => {
    if (parentEmail) loadSubscription(parentEmail);
  }, [parentEmail]);

  const toggleCategory = (val) => {
    setSelectedCategories((prev) =>
      prev.includes(val) ? prev.filter((c) => c !== val) : [...prev, val]
    );
  };

  const toggleEvent = (id) => {
    setSelectedEventIds((prev) =>
      prev.includes(id) ? prev.filter((e) => e !== id) : [...prev, id]
    );
  };

  const handleSave = async () => {
    if (!parentEmail) { toast.error("Email is required."); return; }
    setSaving(true);
    const data = {
      parent_email: parentEmail,
      parent_name: parentName,
      subscribed_categories: selectedCategories,
      subscribed_event_ids: selectedEventIds,
    };
    if (savedSub) {
      await base44.entities.EventSubscription.update(savedSub.id, data);
      setSavedSub((p) => ({ ...p, ...data }));
    } else {
      const created = await base44.entities.EventSubscription.create(data);
      setSavedSub(created);
    }
    queryClient.invalidateQueries({ queryKey: ["subscriptions"] });
    setSaving(false);
    toast.success("Subscription preferences saved!");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="p-2 rounded-xl bg-primary/10 group-hover:bg-primary/20 transition-colors">
              <span className="font-black text-primary text-base leading-none">H</span>
            </div>
            <span className="font-bold text-lg tracking-tight">H Academy</span>
          </Link>
          <div className="flex items-center gap-2">
            <NotificationBell parentEmail={parentEmail} />
            <Link to="/events"><Button variant="ghost" size="sm">Events</Button></Link>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 py-10">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-center gap-3 mb-8">
            <div className="p-2.5 rounded-xl bg-primary/10">
              <Bell className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Notification Settings</h1>
              <p className="text-muted-foreground mt-1">Choose which events and categories to follow.</p>
            </div>
          </div>

          {/* Contact Info */}
          <Card className="border-border/50 shadow-sm mb-6">
            <CardHeader>
              <CardTitle className="text-base">Your Information</CardTitle>
              <CardDescription>We'll use this to send you notifications.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Your Name</Label>
                <Input
                  placeholder="e.g. Jane Smith"
                  value={parentName}
                  onChange={(e) => setParentName(e.target.value)}
                  className="mt-1.5"
                />
              </div>
              <div>
                <Label>Email Address *</Label>
                <Input
                  type="email"
                  placeholder="e.g. jane@email.com"
                  value={parentEmail}
                  onChange={(e) => { if (!emailLocked) { setParentEmail(e.target.value); setSavedSub(null); setSelectedCategories([]); setSelectedEventIds([]); } }}
                  readOnly={emailLocked}
                  className={`mt-1.5 ${emailLocked ? "bg-muted cursor-not-allowed" : ""}`}
                />
                {!emailLocked && parentEmail && (
                  <Button variant="ghost" size="sm" className="mt-1 text-primary" onClick={() => loadSubscription(parentEmail)}>
                    Load existing subscription
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Category Subscriptions */}
          <Card className="border-border/50 shadow-sm mb-6">
            <CardHeader>
              <CardTitle className="text-base">Subscribe by Category</CardTitle>
              <CardDescription>Get notified whenever a new or updated event matches these categories.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {CATEGORIES.map((cat) => {
                  const Icon = cat.icon;
                  const checked = selectedCategories.includes(cat.value);
                  return (
                    <button
                      key={cat.value}
                      onClick={() => toggleCategory(cat.value)}
                      className={`flex items-center gap-2.5 p-3 rounded-xl border-2 transition-all text-left ${
                        checked ? "border-primary bg-primary/5" : "border-border hover:border-primary/40 hover:bg-muted/50"
                      }`}
                    >
                      <Icon className={`w-4 h-4 ${checked ? "text-primary" : cat.color}`} />
                      <span className={`text-sm font-medium ${checked ? "text-primary" : ""}`}>{cat.label}</span>
                      {checked && <CheckCircle2 className="w-3.5 h-3.5 text-primary ml-auto" />}
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Individual Event Subscriptions */}
          <Card className="border-border/50 shadow-sm mb-8">
            <CardHeader>
              <CardTitle className="text-base">Subscribe to Specific Events</CardTitle>
              <CardDescription>Get notified about updates or announcements for individual events.</CardDescription>
            </CardHeader>
            <CardContent>
              {events.length === 0 ? (
                <p className="text-sm text-muted-foreground">No upcoming events found.</p>
              ) : (
                <div className="space-y-2">
                  {events.map((ev) => {
                    const checked = selectedEventIds.includes(ev.id);
                    return (
                      <div
                        key={ev.id}
                        onClick={() => toggleEvent(ev.id)}
                        className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                          checked ? "border-primary bg-primary/5" : "border-border hover:bg-muted/50"
                        }`}
                      >
                        <Checkbox checked={checked} onCheckedChange={() => toggleEvent(ev.id)} onClick={(e) => e.stopPropagation()} />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{ev.title}</p>
                          <p className="text-xs text-muted-foreground">{ev.date}{ev.start_time ? ` · ${ev.start_time}` : ""}</p>
                        </div>
                        <span className="text-xs capitalize text-muted-foreground bg-muted px-2 py-0.5 rounded-full">{ev.category}</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          <Button onClick={handleSave} size="lg" className="w-full gap-2" disabled={saving}>
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Bell className="w-4 h-4" />}
            Save Notification Preferences
          </Button>
        </motion.div>
      </div>
    </div>
  );
}