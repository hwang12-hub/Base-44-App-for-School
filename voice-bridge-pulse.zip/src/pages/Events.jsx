import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { GraduationCap, Plus, CalendarDays, Settings, Bell, BookOpen, Dumbbell, Palette, Users, PartyPopper, MoreHorizontal, CheckCircle2, Loader2, ChevronDown, ChevronUp } from "lucide-react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import EventCalendar from "../components/events/EventCalendar";
import EventFormModal from "../components/events/EventFormModal";
import EventDetailModal from "../components/events/EventDetailModal";
import ChatWidget from "../components/chatbot/ChatWidget";
import NotificationBell from "../components/notifications/NotificationBell";

const CATEGORIES = [
  { value: "academic", label: "Academic", icon: BookOpen, color: "text-primary" },
  { value: "sports",   label: "Sports",   icon: Dumbbell,  color: "text-chart-3" },
  { value: "arts",     label: "Arts",     icon: Palette,   color: "text-chart-4" },
  { value: "social",   label: "Social",   icon: Users,     color: "text-accent-foreground" },
  { value: "holiday",  label: "Holiday",  icon: PartyPopper, color: "text-destructive" },
  { value: "other",    label: "Other",    icon: MoreHorizontal, color: "text-muted-foreground" },
];

export default function Events() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [userEmail, setUserEmail] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [showAlerts, setShowAlerts] = useState(false);
  const [savedSub, setSavedSub] = useState(null);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [selectedEventIds, setSelectedEventIds] = useState([]);
  const [saving, setSaving] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then((u) => {
      if (u?.role === "admin") setIsAdmin(true);
      if (u?.email) {
        setUserEmail(u.email);
        base44.entities.EventSubscription.filter({ parent_email: u.email }).then((subs) => {
          if (subs.length > 0) {
            setSavedSub(subs[0]);
            setSelectedCategories(subs[0].subscribed_categories || []);
            setSelectedEventIds(subs[0].subscribed_event_ids || []);
          }
        });
      }
    }).catch(() => {});
  }, []);

  const toggleCategory = (val) =>
    setSelectedCategories((prev) => prev.includes(val) ? prev.filter((c) => c !== val) : [...prev, val]);

  const toggleEvent = (id) =>
    setSelectedEventIds((prev) => prev.includes(id) ? prev.filter((e) => e !== id) : [...prev, id]);

  const handleSave = async () => {
    if (!userEmail) { toast.error("You must be logged in to save preferences."); return; }
    setSaving(true);
    const data = { parent_email: userEmail, subscribed_categories: selectedCategories, subscribed_event_ids: selectedEventIds };
    if (savedSub) {
      await base44.entities.EventSubscription.update(savedSub.id, data);
    } else {
      const created = await base44.entities.EventSubscription.create(data);
      setSavedSub(created);
    }
    setSaving(false);
    toast.success("Alert preferences saved!");
  };

  const { data: events = [], isLoading } = useQuery({
    queryKey: ["events"],
    queryFn: () => base44.entities.Event.list("date"),
  });

  const handleSaved = () => queryClient.invalidateQueries({ queryKey: ["events"] });
  const handleDeleted = () => queryClient.invalidateQueries({ queryKey: ["events"] });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="p-2 rounded-xl bg-primary/10 group-hover:bg-primary/20 transition-colors">
              <span className="font-black text-primary text-base leading-none">H</span>
            </div>
            <span className="font-bold text-lg tracking-tight">H Academy</span>
          </Link>
          <div className="flex items-center gap-2">
            {isAdmin && (
              <Button onClick={() => { setEditingEvent(null); setShowForm(true); }} size="sm" className="gap-1.5">
                <Plus className="w-4 h-4" /> Add Event
              </Button>
            )}
            <NotificationBell parentEmail={userEmail} />
            <Link to="/feedback"><Button variant="ghost" size="sm">Feedback</Button></Link>
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-10">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-center gap-3 mb-8">
            <div className="p-2.5 rounded-xl bg-primary/10">
              <CalendarDays className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold tracking-tight">School Events</h1>
              <p className="text-muted-foreground mt-1">Stay up to date with upcoming school activities.</p>
            </div>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-20">
              <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
            </div>
          ) : (
            <EventCalendar
              events={events}
              onSelectEvent={setSelectedEvent}
            />
          )}

          {/* Alert Preferences Section */}
          <div className="mt-8">
            <button
              onClick={() => setShowAlerts((p) => !p)}
              className="w-full flex items-center justify-between p-4 rounded-xl border border-border bg-card hover:bg-muted/40 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-primary/10">
                  <Bell className="w-4 h-4 text-primary" />
                </div>
                <div className="text-left">
                  <p className="font-semibold text-sm">Alert Preferences</p>
                  <p className="text-xs text-muted-foreground">
                    {selectedCategories.length + selectedEventIds.length > 0
                      ? `${selectedCategories.length} categor${selectedCategories.length === 1 ? "y" : "ies"} · ${selectedEventIds.length} event${selectedEventIds.length === 1 ? "" : "s"} selected`
                      : "Subscribe to event notifications"}
                  </p>
                </div>
              </div>
              {showAlerts ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
            </button>

            <AnimatePresence>
              {showAlerts && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <div className="pt-4 space-y-4">
                    {/* Category Subscriptions */}
                    <Card className="border-border/50">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm">Subscribe by Category</CardTitle>
                        <CardDescription className="text-xs">Get notified for any new or updated event in these categories.</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {CATEGORIES.map((cat) => {
                            const Icon = cat.icon;
                            const checked = selectedCategories.includes(cat.value);
                            return (
                              <button
                                key={cat.value}
                                onClick={() => toggleCategory(cat.value)}
                                className={`flex items-center gap-2 p-2.5 rounded-lg border-2 transition-all text-left ${
                                  checked ? "border-primary bg-primary/5" : "border-border hover:border-primary/40 hover:bg-muted/40"
                                }`}
                              >
                                <Icon className={`w-3.5 h-3.5 ${checked ? "text-primary" : cat.color}`} />
                                <span className={`text-xs font-medium ${checked ? "text-primary" : ""}`}>{cat.label}</span>
                                {checked && <CheckCircle2 className="w-3 h-3 text-primary ml-auto" />}
                              </button>
                            );
                          })}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Individual Event Subscriptions */}
                    <Card className="border-border/50">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm">Subscribe to Specific Events</CardTitle>
                        <CardDescription className="text-xs">Get notified about updates or announcements for individual events.</CardDescription>
                      </CardHeader>
                      <CardContent>
                        {events.length === 0 ? (
                          <p className="text-xs text-muted-foreground">No upcoming events found.</p>
                        ) : (
                          <div className="space-y-1.5 max-h-60 overflow-y-auto">
                            {events.map((ev) => {
                              const checked = selectedEventIds.includes(ev.id);
                              return (
                                <div
                                  key={ev.id}
                                  onClick={() => toggleEvent(ev.id)}
                                  className={`flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer transition-all ${
                                    checked ? "border-primary bg-primary/5" : "border-border hover:bg-muted/40"
                                  }`}
                                >
                                  <Checkbox checked={checked} onCheckedChange={() => toggleEvent(ev.id)} onClick={(e) => e.stopPropagation()} />
                                  <div className="flex-1 min-w-0">
                                    <p className="text-xs font-medium truncate">{ev.title}</p>
                                    <p className="text-xs text-muted-foreground">{ev.date}{ev.start_time ? ` · ${ev.start_time}` : ""}</p>
                                  </div>
                                  <span className="text-xs capitalize text-muted-foreground bg-muted px-2 py-0.5 rounded-full">{ev.category}</span>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    <Button onClick={handleSave} className="w-full gap-2" disabled={saving}>
                      {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Bell className="w-4 h-4" />}
                      Save Alert Preferences
                    </Button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>

      <EventFormModal
        open={showForm}
        onClose={() => setShowForm(false)}
        event={editingEvent}
        onSaved={handleSaved}
      />

      <EventDetailModal
        event={selectedEvent}
        isAdmin={isAdmin}
        onClose={() => setSelectedEvent(null)}
        onEdit={(e) => { setEditingEvent(e); setShowForm(true); }}
        onDeleted={handleDeleted}
      />

      <ChatWidget />
    </div>
  );
}