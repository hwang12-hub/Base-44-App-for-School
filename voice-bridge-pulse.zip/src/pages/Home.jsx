import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { CalendarDays, Images, MessageSquare, Star, Bell, LayoutDashboard, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import NotificationBell from "../components/notifications/NotificationBell";

const sections = [
  {
    to: "/events",
    icon: CalendarDays,
    color: "bg-primary/10 text-primary",
    border: "hover:border-primary/40",
    title: "School Events",
    description: "Browse the calendar, stay informed about upcoming activities, and subscribe to alerts for the events that matter to you.",
    cta: "View Events",
  },
  {
    to: "/gallery",
    icon: Images,
    color: "bg-chart-4/10 text-chart-4",
    border: "hover:border-chart-4/40",
    title: "Community Gallery",
    description: "Share and explore photos and videos from school life. A space for memories created together.",
    cta: "Open Gallery",
  },
  {
    to: "/feedback",
    icon: Star,
    color: "bg-accent/20 text-accent-foreground",
    border: "hover:border-accent/40",
    title: "Share Feedback",
    description: "Rate your child's class and teacher experience. Your voice helps us grow and improve every day.",
    cta: "Give Feedback",
  },
  {
    to: "/settings",
    icon: Bell,
    color: "bg-chart-3/10 text-chart-3",
    border: "hover:border-chart-3/40",
    title: "Notification Alerts",
    description: "Manage your preferences and choose which event categories or individual events to follow.",
    cta: "Manage Alerts",
  },
];

export default function Home() {
  const [user, setUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    base44.auth.me().then((u) => {
      if (u) { setUser(u); if (u.role === "admin") setIsAdmin(true); }
    }).catch(() => {});
  }, []);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="p-2 rounded-xl bg-primary/10 group-hover:bg-primary/20 transition-colors">
              <span className="font-black text-primary text-base leading-none">H</span>
            </div>
            <span className="font-bold text-lg tracking-tight">H Academy</span>
          </Link>
          <div className="flex items-center gap-1">
            <NotificationBell parentEmail={user?.email || ""} />
            {isAdmin && (
              <Link to="/dashboard">
                <Button variant="ghost" size="sm" className="gap-1.5">
                  <LayoutDashboard className="w-4 h-4" /> Dashboard
                </Button>
              </Link>
            )}
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/5 pointer-events-none" />
        <div className="max-w-5xl mx-auto px-4 py-20 md:py-28 text-center relative">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary text-sm font-medium px-4 py-1.5 rounded-full mb-6">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              Welcome to H Academy
            </div>
            <h1 className="text-4xl md:text-6xl font-black tracking-tight text-foreground mb-5 leading-tight">
              Where School Feels<br />
              <span className="text-primary">Like Home</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-xl mx-auto mb-8 leading-relaxed">
              Stay connected with your child's school journey. From events and galleries to feedback and notifications — everything in one place.
            </p>
            <Link to="/events">
              <Button size="lg" className="gap-2 rounded-full px-8 shadow-md">
                Get Started <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Greeting */}
      {user && (
        <div className="max-w-5xl mx-auto px-4 -mt-2 mb-2">
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }} className="text-sm text-muted-foreground">
            Welcome back, <span className="font-semibold text-foreground">{user.full_name || user.email}</span> 👋
          </motion.p>
        </div>
      )}

      {/* Section Cards */}
      <section className="max-w-5xl mx-auto px-4 py-10 flex-1">
        <div className="grid sm:grid-cols-2 gap-5">
          {sections.map((s, i) => {
            const Icon = s.icon;
            return (
              <motion.div
                key={s.to}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + i * 0.08 }}
              >
                <Link to={s.to} className={`group flex flex-col gap-4 p-6 rounded-2xl border border-border bg-card hover:shadow-lg transition-all duration-200 h-full ${s.border}`}>
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${s.color}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <h2 className="font-bold text-lg mb-1.5">{s.title}</h2>
                    <p className="text-sm text-muted-foreground leading-relaxed">{s.description}</p>
                  </div>
                  <div className="flex items-center gap-1.5 text-sm font-semibold text-primary group-hover:gap-2.5 transition-all">
                    {s.cta} <ArrowRight className="w-4 h-4" />
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 mt-10">
        <div className="max-w-5xl mx-auto px-4 py-6 flex flex-col sm:flex-row items-center justify-between gap-2">
          <Link to="/" className="flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors">
            <span className="font-black text-primary">H</span> H Academy
          </Link>
          <p className="text-xs text-muted-foreground">Building a stronger school community, together.</p>
        </div>
      </footer>
    </div>
  );
}